const { Router } = require('express');
const { MongoClient, ObjectId } = require('mongodb');

const statuses = ['Not Started', 'In Progress', 'Completed'];
const limits = { name: 100, owner: 100, status: 20, startDate: 10, dueDate: 10, description: 500 };
function isDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(value);
  return !Number.isNaN(+date) && date.toISOString().slice(0, 10) === value;
}
function validate(req, res, next) {
  const project = {};
  for (const [key, max] of Object.entries(limits)) {
    const raw = req.body?.[key];
    const value = typeof raw === 'string' ? raw.trim() : '';
    if (!value || value.length > max) return res.status(400).json({ message: 'Enter a valid ' + key + '.' });
    project[key] = value;
  }
  if (!statuses.includes(project.status) || !isDate(project.startDate) ||
      !isDate(project.dueDate) || project.dueDate < project.startDate) {
    return res.status(400).json({ message: 'Choose a valid status and dates. The due date cannot be before the start date.' });
  }
  req.project = project;
  next();
}

function projectRoutes() {
  const router = Router();
  const client = new MongoClient(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017', { serverSelectionTimeoutMS: 3000 });
  const projects = client.db(process.env.MONGODB_DB || 'project_progress_tracker').collection('projects');
  const missing = res => res.status(404).json({ message: 'Project not found.' });
  router.param('id', (req, res, next, id) => {
    if (!/^[a-f0-9]{24}$/i.test(id)) return res.status(400).json({ message: 'Invalid project ID.' });
    req.projectId = new ObjectId(id);
    next();
  });
  router.get('/', async (req, res) => res.json(await projects.find().sort({ _id: -1 }).toArray()));
  router.get('/:id', async (req, res) => {
    const project = await projects.findOne({ _id: req.projectId });
    return project ? res.json(project) : missing(res);
  });
  router.post('/', validate, async (req, res) => {
    const { insertedId } = await projects.insertOne(req.project);
    res.location('/projects/' + insertedId).status(201).json({ ...req.project, _id: insertedId });
  });
  router.put('/:id', validate, async (req, res) => {
    const project = await projects.findOneAndUpdate({ _id: req.projectId }, { $set: req.project }, { returnDocument: 'after' });
    return project ? res.json(project) : missing(res);
  });
  router.delete('/:id', async (req, res) => {
    const { deletedCount } = await projects.deleteOne({ _id: req.projectId });
    return deletedCount ? res.sendStatus(204) : missing(res);
  });
  return { router, client };
}
module.exports = { projectRoutes };
