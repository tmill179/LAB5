import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

interface ProjectInput {
  name: string;
  owner: string;
  status: string;
  startDate: string;
  dueDate: string;
  description: string;
}
interface Project extends ProjectInput { _id: string; }

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './app.html',
})
export class App implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly fb = inject(FormBuilder).nonNullable;
  private readonly url = 'http://localhost:8000/projects';
  readonly statuses = ['Not Started', 'In Progress', 'Completed'];
  readonly projects = signal<Project[]>([]);
  readonly selected = signal<Project | null>(null);
  readonly editing = signal<string | null>(null);
  readonly pendingDelete = signal<Project | null>(null);
  readonly busy = signal(false);
  readonly loaded = signal(false);
  readonly message = signal('');
  readonly error = signal('');
  readonly form = this.fb.group({
    name: ['', [Validators.required, Validators.maxLength(100)]],
    owner: ['', [Validators.required, Validators.maxLength(100)]],
    status: ['Not Started', Validators.required],
    startDate: ['', Validators.required],
    dueDate: ['', Validators.required],
    description: ['', [Validators.required, Validators.maxLength(500)]],
  });

  ngOnInit() { void this.refresh(); }

  private async perform(work: () => Promise<void>) {
    if (this.busy()) return;
    this.busy.set(true);
    this.message.set('');
    this.error.set('');
    try {
      await work();
    } catch (err) {
      this.error.set(err instanceof HttpErrorResponse && err.error?.message
        ? err.error.message : 'Could not reach the project server. Check that Express is running and try again.');
    } finally {
      this.busy.set(false);
    }
  }

  async refresh() {
    await this.perform(async () => {
      this.projects.set(await firstValueFrom(this.http.get<Project[]>(this.url)));
      this.loaded.set(true);
    });
  }

  async view(id: string) {
    await this.perform(async () => {
      this.selected.set(await firstValueFrom(this.http.get<Project>(this.url + '/' + id)));
    });
  }

  async edit(id: string) {
    await this.perform(async () => {
      const project = await firstValueFrom(this.http.get<Project>(this.url + '/' + id));
      this.form.reset(project);
      this.editing.set(id);
      document.getElementById('project-name')?.focus();
    });
  }

  cancelEdit() {
    this.editing.set(null);
    this.form.reset();
  }

  async save() {
    if (this.busy()) return;
    this.form.markAllAsTouched();
    const value = this.form.getRawValue();
    value.name = value.name.trim();
    value.owner = value.owner.trim();
    value.description = value.description.trim();
    if (this.form.invalid || !value.name || !value.owner || !value.description) {
      this.message.set('');
      this.error.set('Please complete all six fields.');
      return;
    }
    if (value.dueDate < value.startDate) {
      this.message.set('');
      this.error.set('The due date cannot be before the start date.');
      return;
    }
    const id = this.editing();
    await this.perform(async () => {
      const saved = await firstValueFrom(id
        ? this.http.put<Project>(this.url + '/' + id, value)
        : this.http.post<Project>(this.url, value));
      this.projects.update(rows => id ? rows.map(p => p._id === id ? saved : p) : [saved, ...rows]);
      this.loaded.set(true);
      this.selected.set(saved);
      this.cancelEdit();
      this.message.set(id ? 'Project updated.' : 'Project saved.');
    });
  }

  async remove() {
    const project = this.pendingDelete();
    if (!project) return;
    await this.perform(async () => {
      await firstValueFrom(this.http.delete(this.url + '/' + project._id));
      this.projects.update(rows => rows.filter(p => p._id !== project._id));
      if (this.selected()?._id === project._id) this.selected.set(null);
      if (this.editing() === project._id) this.cancelEdit();
      this.pendingDelete.set(null);
      this.message.set('Project deleted.');
    });
  }
}
