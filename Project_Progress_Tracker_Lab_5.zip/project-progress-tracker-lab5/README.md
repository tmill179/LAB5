# Project Progress Tracker Lab 5

Lab 5 extends the existing Angular app component with a project form, a saved project list, and an individual project details view. Express stores the records in MongoDB. The form uses project name, team member, status, start date, due date, and description. The same form handles creating and editing.

## Run locally

1. Start MongoDB Community Server on port 27017. On Windows you can install it as a service using the [MongoDB Windows guide](https://www.mongodb.com/docs/v8.0/tutorial/install-mongodb-on-windows/).
2. In Command Prompt, open this project's root folder (the one containing angular.json). Run `npm ci`, then `npm start`. Leave the window open.
3. In a second Command Prompt in that same folder, run `cd server`, then `npm ci`, then `npm start`. Leave this window open too.
4. Open http://localhost:4200. If you still have Lab 4 running, stop its two Command Prompt processes with Ctrl+C first because the labs use the same ports.

The API defaults to `mongodb://127.0.0.1:27017`, database `project_progress_tracker`, collection `projects`. The collection is created on the first save. You can override the connection in the server process with `MONGODB_URI` and `MONGODB_DB`. Keep database credentials out of GitHub.

## Project API

| Action | Request | Success |
| --- | --- | --- |
| Create | POST /projects | 201 |
| List | GET /projects | 200 |
| View details | GET /projects/:id | 200 |
| Update | PUT /projects/:id | 200 |
| Delete | DELETE /projects/:id | 204 |

Angular handles every action in `src/app/app.ts` and its template. Express validates the six inputs, checks the date order, and uses MongoDB's generated ID to look up, update, or delete the right record. The previous lab's milestone API is still available at `/milestones`.

For a quick check, create a project, refresh the page, use View to check the six fields, edit its status, and confirm Delete. The deleted record should no longer show in the list after another refresh.
